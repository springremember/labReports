from django.apps import AppConfig


class HealthytestConfig(AppConfig):
    name = 'healthyTest'
