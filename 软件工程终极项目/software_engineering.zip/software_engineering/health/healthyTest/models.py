from django.db import models
import time

# Create your models here.
#体检项目表：①项目编号 ②项目名字 ③项目正常值
class project(models.Model):
	Pid=models.CharField(max_length=4)
	name=models.CharField(max_length=30)
	value=models.CharField(max_length=30)

	def __str__(self):
		return self.Pid+":"+self.name

#体检项目推荐表：①推荐类型，推荐项目代码组合
class recommendation(models.Model):
	type=models.CharField(max_length=30)
	projects=models.CharField(max_length=60)

	def __str__(self):
		return self.type


class goAbroad(models.Model):
	type=models.CharField(max_length=30)
	projects=models.CharField(max_length=60)

	def __str__(self):
		return self.type

#个人信息表：①身份证号 ②姓名 ③性别 ④密码 ⑤体检日期 ⑥手机号码 ⑦地址 ⑧所有体检项目
class peopleInfor(models.Model):
	identification=models.IntegerField()
	name=models.CharField(max_length=30)
	sex=models.BooleanField()
	date=models.IntegerField()
	phoneNum=models.IntegerField()
	address=models.CharField(max_length=100)
	finish=models.BooleanField(default=False)
	#身高、体重
	P10=models.IntegerField()
	P11=models.IntegerField()
	#白细胞、血小板
	P20=models.FloatField()
	P21=models.IntegerField()
	#左右眼裸眼视力
	P30=models.FloatField()
	P31=models.FloatField()
	#血清尿素、尿素
	P40=models.FloatField()
	P41=models.IntegerField()
	#血糖、血压、血脂
	P50=models.FloatField()
	P51=models.CharField(max_length=20)
	P52=models.FloatField()
	#肺容量、肺通气
	P60=models.FloatField()
	P61=models.IntegerField()

	def __str__(self):
		time_local=time.localtime(self.date)
		dateStr=time.strftime("%Y-%m-%d",time_local)
		return str(self.identification)+":"+self.name+":"+dateStr

class peoplePassword(models.Model):
	identification=models.IntegerField()
	password=models.CharField(max_length=16)
	def __str__(self):
		return str(self.identification)