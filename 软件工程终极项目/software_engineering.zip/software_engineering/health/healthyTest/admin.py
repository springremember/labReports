from django.contrib import admin
from healthyTest.models import project,recommendation,peopleInfor,peoplePassword,goAbroad

# Register your models here.
admin.site.register(project)
admin.site.register(recommendation)
admin.site.register(peopleInfor)
admin.site.register(peoplePassword)
admin.site.register(goAbroad)