from django.shortcuts import render
import time
from healthyTest.models import project,recommendation,peopleInfor,peoplePassword,goAbroad

# Create your views here.

def home(request):
	return render(request,"home.html")

def orderLogin(request):
	return render(request,"orderLogin.html")

def selectProject(request):
	ID=int(request.POST["ID"])
	name=request.POST["name"]
	sex=request.POST["sex"]
	phoneNumber=request.POST["phoneNumber"]
	address=request.POST["address"]
	date=request.POST["user_date"]
	testType=request.POST["type"]
	input={}
	input["ID"]=ID
	input["name"]=name
	input["sex"]=sex
	input["phoneNumber"]=phoneNumber
	input["address"]=address
	input["date"]=date
	input["testType"]=testType
	peopleList=peopleInfor.objects.all()
	if testType=="society":
		reList=recommendation.objects.all()
		input["reList"]=reList
		for i in peopleList:
			if i.identification==ID:
				if i.name!=name:
					return render(request,"nameError.html",input)
				else:
					return render(request,"selectProject.html",input)
		return render(request,"selectProject.html",input)
	else:
		reList=goAbroad.objects.all()
		input["reList"]=reList
		for i in peopleList:
			if i.identification==ID:
				if i.name!=name:
					return render(request,"nameError.html",input)
				else:
					return render(request,"goAbroad.html",input)
		return render(request,"goAbroad.html",input)
	

def socialTest(request):
	name=request.POST["name"]
	ID=request.POST["ID"]
	sex=request.POST["sex"]
	phoneNumber=request.POST["phoneNumber"]
	address=request.POST["address"]
	testType=request.POST["Menu"]
	date=request.POST["date"]
	input={}
	input["name"]=name
	input["sex"]=sex
	input["phoneNumber"]=phoneNumber
	input["address"]=address
	input["date"]=date
	input["ID"]=ID
	recommend=recommendation.objects.get(type=testType)
	reList=recommend.projects.split("-")
	input["reList"]=reList
	projectList=project.objects.all()
	input["projectList"]=projectList
	return render(request,"socialTest.html",input)

def goTest(request):
	name=request.POST["name"]
	ID=request.POST["ID"]
	sex=request.POST["sex"]
	phoneNumber=request.POST["phoneNumber"]
	address=request.POST["address"]
	testType=request.POST["Menu"]
	date=request.POST["date"]
	input={}
	input["name"]=name
	input["sex"]=sex
	input["phoneNumber"]=phoneNumber
	input["address"]=address
	input["date"]=date
	input["ID"]=ID
	recommend=goAbroad.objects.get(type=testType)
	reList=recommend.projects.split("-")
	input["reList"]=reList
	projectList=project.objects.all()
	input["projectList"]=projectList
	return render(request,"goTest.html",input)

def submit(request):
	input={}
	if "P10" in request.POST:
		GP10=-1
	else:
		GP10=0
	if "P11" in request.POST:
		GP11=-1
	else:
		GP11=0
	if "P20" in request.POST:
		GP20=-1.0
	else:
		GP20=0.0
	if "P21" in request.POST:
		GP21=-1
	else:
		GP21=0
	if "P30" in request.POST:
		GP30=-1.0
	else:
		GP30=0.0
	if "P31" in request.POST:
		GP31=-1.0
	else:
		GP31=0.0
	if "P40" in request.POST:
		GP40=-1.0
	else:
		GP40=0.0
	if "P41" in request.POST:
		GP41=-1
	else:
		GP41=0
	if "P50" in request.POST:
		GP50=-1.0
	else:
		GP50=0.0
	if "P51" in request.POST:
		GP51="-1"
	else:
		GP51="0"
	if "P52" in request.POST:
		GP52=-1.0
	else:
		GP52=0.0
	if "P60" in request.POST:
		GP60=-1.0
	else:
		GP60=0.0
	if "P61" in request.POST:
		GP61=-1
	else:
		GP61=0
	if request.POST["sex"]=="male":
		Gsex=True
	else:
		Gsex=False
	date=request.POST["date"]
	input["date"]=date
	date=date+" 12:00:00"
	timeArray = time.strptime(date, "%Y-%m-%d %H:%M:%S")
	Gdate = int(time.mktime(timeArray))
	temp=peopleInfor(identification=request.POST["ID"],name=request.POST["name"],sex=Gsex,date=int(Gdate),phoneNum=int(request.POST["phoneNumber"]),address=request.POST["address"],P10
		=GP10,P11=GP11,P20=GP20,P21=GP21,P30=GP30,P31=GP31,P40=GP40,P41=GP41,P50=GP50,P51=GP51,P52=GP52,P60=GP60,P61=GP61)
	temp.save()
	if request.POST["sex"]=="male":
		name=request.POST["name"]+"先生"
	else:
		name=request.POST["name"]+"女士"
	input["name"]=name
	return render(request,"submit.html",input)

def search(request):
	input={}
	input["tips"]=""
	return render(request,"search.html",input)

def loginCheck(request):
	input={}
	ID=request.POST["ID"]
	input["ID"]=ID
	password=request.POST["password"]
	input["password"]=password
	check=peoplePassword.objects.filter(identification=ID)
	if len(check)==0:
		input["tips"]="无此身份证号的记录，请重新确认后查询"
		return render(request,"search.html",input)
	else:
		if check[0].password==password:
			reportList=peopleInfor.objects.filter(identification=ID,finish=True)
			for i in reportList:
				time_local=time.localtime(i.date)
				i.dateStr=time.strftime("%Y-%m-%d",time_local)
			input["reportList"]=reportList
			return render(request,"searchList.html",input)
		else:
			input["tips"]="密码错误，请重新输入。"
			return render(request,"search.html",input)

class show():
	def __init__(self):
		self.id=0
	def setName(self,name):
		self.name=name
	def setValue(self,value):
		self.value=value
	def setRange(self,normal):
		self.normal=normal

def showReport(request):
	input={}
	input["ID"]=request.POST["ID"]
	input["password"]=request.POST["password"]
	showList=[]
	if "choose" not in request.POST:
		return loginCheck(request)
	choose=request.POST["choose"]
	ID=request.POST["ID"]
	reportShow=peopleInfor.objects.get(identification=ID,date=choose)
	time_local=time.localtime(reportShow.date)
	reportShow.dateStr=time.strftime("%Y-%m-%d",time_local)
	input["reportShow"]=reportShow
	projects=project.objects.all()
	if reportShow.P10==0 or reportShow.P10=="0":
		pass
	else:
		temp=show()
		temp.setName(projects[0].name)
		temp.setValue(reportShow.P10)
		temp.setRange(projects[0].value)
		showList.append(temp)
	if reportShow.P11==0 or reportShow.P11=="0":
		pass
	else:
		temp=show()
		temp.setName(projects[1].name)
		temp.setValue(reportShow.P11)
		temp.setRange(projects[1].value)
		showList.append(temp)
	if reportShow.P20==0 or reportShow.P20=="0":
		pass
	else:
		temp=show()
		temp.setName(projects[2].name)
		temp.setValue(reportShow.P20)
		temp.setRange(projects[2].value)
		showList.append(temp)
	if reportShow.P21==0 or reportShow.P21=="0":
		pass
	else:
		temp=show()
		temp.setName(projects[3].name)
		temp.setValue(reportShow.P21)
		temp.setRange(projects[3].value)
		showList.append(temp)
	if reportShow.P30==0 or reportShow.P30=="0":
		pass
	else:
		temp=show()
		temp.setName(projects[4].name)
		temp.setValue(reportShow.P30)
		temp.setRange(projects[4].value)
		showList.append(temp)
	if reportShow.P31==0 or reportShow.P31=="0":
		pass
	else:
		temp=show()
		temp.setName(projects[5].name)
		temp.setValue(reportShow.P31)
		temp.setRange(projects[5].value)
		showList.append(temp)
	if reportShow.P40==0 or reportShow.P40=="0":
		pass
	else:
		temp=show()
		temp.setName(projects[6].name)
		temp.setValue(reportShow.P40)
		temp.setRange(projects[6].value)
		showList.append(temp)
	if reportShow.P41==0 or reportShow.P41=="0":
		pass
	else:
		temp=show()
		temp.setName(projects[7].name)
		temp.setValue(reportShow.P41)
		temp.setRange(projects[7].value)
		showList.append(temp)
	if reportShow.P50==0 or reportShow.P50=="0":
		pass
	else:
		temp=show()
		temp.setName(projects[8].name)
		temp.setValue(reportShow.P50)
		temp.setRange(projects[8].value)
		showList.append(temp)
	if reportShow.P51==0 or reportShow.P51=="0":
		pass
	else:
		temp=show()
		temp.setName(projects[9].name)
		temp.setValue(reportShow.P51)
		temp.setRange(projects[9].value)
		showList.append(temp)
	if reportShow.P52==0 or reportShow.P52=="0":
		pass
	else:
		temp=show()
		temp.setName(projects[10].name)
		temp.setValue(reportShow.P52)
		temp.setRange(projects[10].value)
		showList.append(temp)
	if reportShow.P60==0 or reportShow.P60=="0":
		pass
	else:
		temp=show()
		temp.setName(projects[11].name)
		temp.setValue(reportShow.P60)
		temp.setRange(projects[11].value)
		showList.append(temp)
	if reportShow.P61==0 or reportShow.P61=="0":
		pass
	else:
		temp=show()
		temp.setName(projects[12].name)
		temp.setValue(reportShow.P61)
		temp.setRange(projects[12].value)
		showList.append(temp)
	input["showList"]=showList
	return render(request,"show.html",input)