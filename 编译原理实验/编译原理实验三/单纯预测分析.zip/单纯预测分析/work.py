from select2M import *


#用于索引数组
terminal={'E':0,'A':1,'T':2,'B':3,'F':4}
noterminal={'i':0,'(':1,')':2,'#':3,'+':4,'*':5}

#分析预测表
M=[(["0"]*6) for i in range(5)]

#已知SELECT集合
SELECT=["SELECT(E->TA)={i,(}","SELECT(A->+TA)={+}","SELECT(A->&)={),#}","SELECT(T->FB)={i,(}","SELECT(B->*FB)={*}","SELECT(B->&)={+,),#}","SLEECT(F->i)={i}","SELECT(F->(E))={(}"]

for strSelect in SELECT:
	tempList=selectM(strSelect)
	line=terminal[tempList[0][0]]
	for i in tempList[1]:
		column=noterminal[i]
		M[line][column]=tempList[0][1]


stack="#E"

strFor=input("请输入要判别的字符串:")
strFor=strFor+'#'

counter=1

print("步骤"+'\t'+"分析栈"+'\t\t'+"剩余输入串"+'\t\t'+"推导式")
while 1:
	print(counter,end='\t')
	X=stack[-1]
	a=strFor[0]
	print(stack,end='\t\t')
	print(strFor,end='\t\t\t')
	if X in noterminal.keys():
		if X=="#" and a=="#":
			print("可接收的输入串")
			break
		else:
			if X==a:
				stack=stack[:-1]
				strFor=strFor[1:]
				print(X+"匹配")
			else:
				print("非法输入串")
				break
	else:
		if M[terminal[X]][noterminal[a]]=="0":
			print("非法输入串")
			break
		else:
			if M[terminal[X]][noterminal[a]]=="&":
				stack=stack[:-1]
				print(X+"->&")
			else:
				stack=stack[:-1]
				stack=stack+M[terminal[X]][noterminal[a]][::-1]
				print(X+"->"+M[terminal[X]][noterminal[a]])
	counter=counter+1
