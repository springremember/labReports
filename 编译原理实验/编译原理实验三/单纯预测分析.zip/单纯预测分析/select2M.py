def selectM(str):
	str=str[6:]
	list=str.split('=')
	list[0]=list[0][1:-1]
	list[1]=list[1][1:-1]
	list[0]=list[0].split('->')
	list[1]=list[1].split(',')
	return list