#求first集合

# noterminal={'E':0,'A':1,'T':2,'B':3,'F':4}
# terminal={'i':0,'(':1,')':2,'#':3,'+':4,'*':5}

# G=["E->TA","A->+TA|&","T->FB","B->*FB|&","F->i|(E)"]

# null=set(['A','B'])
# unNull=set(['E','T','F'])

# first=[set([]),set([]),set([]),set([]),set([])]

#输入非终结符字典、终结符字典、语法列表G,已经判空的集合，已经非空的终结符集合、first集合
def getFirst(noterminal,terminal,G,null,unNull,first):
	#第一步，对于能推出空的非终结符，在他们的first集合中添加“&”
	nullList=list(null)
	for i in nullList:
		first[noterminal[i]]=first[noterminal[i]] | set(["&"])

	#第二步，找出确定的first集合，即first中可以直接找到终结符
	for GStr in G:
		tempList=GStr.split("->")
		tempList[1]=tempList[1].split("|")
		for i in tempList[1]:
			for j in i[0]:
				if j in terminal.keys():
					first[noterminal[tempList[0]]].add(j)


	#第三步，循环叠加
	#oldCounter和newCounter保存一次循环后的集合中元素个数，如果相等即退出循环
	oldCounter=0
	newCounter=0
	for i in first:
		oldCounter=oldCounter+len(i)
	while 1:
	#当集合中数据不变时结束，否则更新变量
		if oldCounter==newCounter:
			break
		else:
			oldCounter=newCounter
		#提取类似E->TE'|(A)的语法式
		for GStr in G:
			tempList=GStr.split("->")
			#tempList=['E',["TE'","A"]],即分开箭头两边和|
			tempList[1]=tempList[1].split("|")
			#对于每一个|分开的推导式
			for i in tempList[1]:
				for j in range(0,len(i)):
					#如果是终结符或者&,那就跳过
					if i[j] in terminal.keys() or i[j]=="&":
						break
					#如果是"'"，那就继续
					elif i[j]=="'":
						continue
					else:
						#查看下一位是否是"'"，要考虑到E'的非终结符
						if j==len(i)-1:
							tempStr=i[j]
						elif i[j+1]=="'":
							tempStr=i[j]+i[j+1]
						else:
							tempStr=i[j]
						#集合的并集
						first[noterminal[tempList[0]]]=first[noterminal[tempList[0]]] | first[noterminal[tempStr]]
						#如果该终结符不能推出空，那就结束
						if tempStr in unNull:
							break
		newCounter=0
		for i in first:
			newCounter=newCounter+len(i)

# getFirst(noterminal,terminal,G,null,unNull,first)
# print(first)


