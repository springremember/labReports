#求follow集

# start="E"

# noterminal={'E':0,"E'":1,'T':2,"T'":3,'F':4}
# terminal={'i':0,'(':1,')':2,'#':3,'+':4,'*':5}

# G=["E->TE'", "E'->+TE'|&", "T->FT'", "T'->*FT'|&", 'F->i|(E)']

# null=set(["E'","T'"])
# unNull=set(['E','T','F'])

# first=[{'i', '('}, {'&', '+'}, {'i', '('}, {'&', '*'}, {'i', '('}]
# follow=[set([]) for i in range(0,len(noterminal))]

#排除单引号干扰，重新排列成列表
#二次更新，排除"|"干扰，形成多维列表
#接收类似 TE'|(E) 形成 [["T","E'"],["(","E",")"]],便于排除单引号干扰
def GSplit(noterminal,terminal,str):
	strList=str.split('|')
	tempList=[[] for i in range(0,len(strList))]
	for j in range(0,len(strList)):
		for i in range(0,len(strList[j])):
			#遇到“'”，跳过
			if strList[j][i]=="'":
				continue
			else:
				#如果是终结符那就直接加入
				if strList[j][i] in terminal.keys():
					tempList[j].append(strList[j][i])
				else:
					#首先判断是否是尾部，以防越界。然后判断是否是单引号特殊情况
					if i==len(strList[j])-1:
						tempList[j].append(strList[j][i])
					else:
						if strList[j][i+1]=="'":
							tempStr=strList[j][i]+strList[j][i+1]
							tempList[j].append(tempStr)
						else:
							tempList[j].append(strList[j][i])
	return tempList




def getFollow(start,noterminal,terminal,G,null,unNull,first,follow):
	#第一步,开始符号的follow集中添加#
	follow[noterminal[start]].add("#")

	#第二步，循环添加follow集合
	#同first函数意义
	oldCounter=0
	for i in follow:
		oldCounter=oldCounter+len(i)
	newCounter=0
	while(1):
		if oldCounter==newCounter:
			break
		else:
			oldCounter=newCounter
		for Gstr in G:
			splitList=Gstr.split('->')
			GList=GSplit(noterminal,terminal,splitList[1])
			#第一层循环，用于 | 情况
			for j in GList:
				for i in range(0,len(j)):
					#遇到非终结符开始
					if j[i] in noterminal.keys():
						#判断是否到尾部，即E->FB,要将follow(E)添加到follow(B)
						if i==len(j)-1:
							follow[noterminal[j[i]]]=follow[noterminal[j[i]]] | follow[noterminal[splitList[0]]]
						else:
							#下一个是终结符，那就直接添加结束
							if j[i+1] in terminal.keys():
								follow[noterminal[j[i]]].add(j[i+1])
							else:
								#下一个非终结符，可能为空需要循环添加
								for k in range(i+1,len(j)):
									if j[k] in terminal.keys():
										follow[noterminal[j[i]]].add(j[k])
									else:
										follow[noterminal[j[i]]]=follow[noterminal[j[i]]] | first[noterminal[j[k]]]
									if j[k] not in null:
										break
									#如果循环到结尾还需要添加一次follow集合
									elif k==len(j)-1:
										follow[noterminal[j[i]]]=follow[noterminal[j[i]]] | follow[noterminal[j[k]]]
									else:
										pass
								#去除follow集合中的空串
								follow[noterminal[j[i]]]=follow[noterminal[j[i]]] - set(["&"])

		newCounter=0
		for i in follow:
			newCounter=newCounter+len(i)


# getFollow(start,noterminal,terminal,G,null,unNull,first,follow)
# print(follow)