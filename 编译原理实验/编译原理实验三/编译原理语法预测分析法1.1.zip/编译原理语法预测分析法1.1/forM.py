# select={"T'->*FT'": {'*'}, "E->TE'": {'(', 'i'}, "E'->+TE'": {'+'}, 'F->(E)': {'('}, "E'->&": {')', '#'}, "T->FT'": {'(', 'i'}, "T'->&": {')', '#', '+'}, 'F->i': {'i'}}
# noterminal={'E':0,"E'":1,'T':2,"T'":3,'F':4}
# terminal={'i':0,'(':1,')':2,'#':3,'+':4,'*':5}

# M=[(["0"]*len(terminal)) for i in range(len(noterminal))]

#简单的根据select字典特性，填充预测分析表
def getM(terminal,noterminal,select,M):
	for i in select:
		line=i.split('->')[0]
		for column in select[i]:
			M[noterminal[line]][terminal[column]]=i.split('->')[1]


# getM(terminal,noterminal,select,M)
# print(M)