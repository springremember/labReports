# noterminal={'E':0,"E'":1,'T':2,"T'":3,'F':4}
# terminal={'i':0,'(':1,')':2,'#':3,'+':4,'*':5}

# M=[["TE'", "TE'", '0', '0', '0', '0'], ['0', '0', '&', '&', "+TE'", '0'], ["FT'", "FT'", '0', '0', '0', '0'], ['0', '0', '&', '&', '&', "*FT'"], ['i', '(E)', '0', '0', '0', '0']]



def analysis(noterminal,terminal,M,start):
	stack="#"+start

	strFor=input("请输入要判别的字符串:")
	strFor=strFor+'#'

	counter=1

	print("步骤"+'\t'+"分析栈"+'\t\t\t'+"剩余输入串"+'\t\t\t'+"推导式")
	while 1:
		print("%- 4d"%(counter),end="\t")
		if stack[-1]=="'":
			X=stack[-2]+stack[-1]
		else:
			X=stack[-1]
		a=strFor[0]
		print("%- 20s"%(stack),end='\t')
		print("%- 25s"%(strFor),end='\t')
		#遇到X是终结符，可能结束或者弹出
		if X in terminal.keys():
			#结束情况
			if X=="#" and a=="#":
				print("可接收的输入串")
				break
			else:
				#弹出情况或者错误情况
				if X==a:
					stack=stack[0:-1]
					strFor=strFor[1:]
					print(X+"匹配")
				else:
					print("非法输入串")
					break
		#X非终结符
		else:
			#如果预测分析表中不存在，出错
			if M[noterminal[X]][terminal[a]]=="0":
				print("非法输入串")
				break
			else:
				#空的特殊情况
				if M[noterminal[X]][terminal[a]]=="&":
					if stack[-1]=="'":
						stack=stack[0:-2]
					else:
						stack=stack[0:-1]
					print(X+"->&")
				else:
					#正常情况，倒序入栈
					if stack[-1]=="'":
						stack=stack[0:-2]
					else:
						stack=stack[0:-1]
					tempStr=M[noterminal[X]][terminal[a]]
					for i in range(0,len(tempStr)):
						if tempStr[i]=="'":
							StrTemp=tempStr[i-1]
							tempStr=tempStr[0:i-1]+"'"+StrTemp+tempStr[i+1:]
					stack=stack+tempStr[::-1]
					print(X+"->"+M[noterminal[X]][terminal[a]])
		counter=counter+1

# analysis(noterminal,terminal,M)