# start="E"

# noterminal={'E':0,"E'":1,'T':2,"T'":3,'F':4}
# terminal={'i':0,'(':1,')':2,'#':3,'+':4,'*':5}

# G=["E->TE'", "E'->+TE'|&", "T->FT'", "T'->*FT'|&", 'F->i|(E)']

# null=set(["E'","T'"])
# unNull=set(['E','T','F'])

# first=[{'i', '('}, {'&', '+'}, {'i', '('}, {'&', '*'}, {'i', '('}]

# follow=[{'#', ')'}, {'#', ')'}, {'+', '#', ')'}, {'+', '#', ')'}, {'+', '*', '#', ')'}]

# select={}


# GStr=[]
 
#用于接收E->TE'中的TE',分割成["T","E'"]
def str2list(str):
	tempList=[]
	for i in range(0,len(str)):
		if i==len(str)-1:
			tempList.append(str[i])
		elif str[i]=="'":
			pass
		else:
			if str[i+1]=="'":
				tempStr=str[i]+str[i+1]
			else:
				tempStr=str[i]
			tempList.append(tempStr)
	return tempList


# def getGStr(G,Gtr):
# 	for i in G:
# 		tempList=i.split("->")
# 		tempList[1]=tempList[1].split("|")
# 		for j in tempList[1]:
# 			tempStr=tempList[0]+"->"+j
# 			GStr.append(tempStr)

# getGStr(G,GStr)

# def setSelect(GStr,select):
# 	for i in GStr:
# 		select[i]=set([])


# setSelect(GStr,select)
#循环算法
def getSelect(GStr,terminal,noterminal,null,unNull,first,follow,select):
	for i in GStr:
		tempList=i.split('->')
		tempList[1]=str2list(tempList[1])
		#循环判断，遇到终结符或者不能推出空的非终结符停止
		for j in range(0,len(tempList[1])):
			#终结符
			if tempList[1][j] in terminal.keys():
				select[i].add(tempList[1][j])
				break
			#即E->&情况
			elif tempList[1][j]=="&":
				select[i]=select[i] | follow[noterminal[tempList[0]]]
				break
			#即遇到不能推出空的非终结符
			elif tempList[1][j] in unNull:
				select[i]=select[i] | first[noterminal[tempList[1][j]]]
				break
			#遇到可以推出空的，不断循环。特殊：尾部情况
			else:
				#尾部情况
				if j==len(tempList[1])-1:
					select[i]=select[i] | follow[noterminal[tempList[0]]]
					select[i]=select[i] | set(first[noterminal[tempList[1][j]]])
					select[i]=select[i] - set(["&"])
				else:
					select[i]=select[i] | set(first[noterminal[tempList[1][j]]])
					select[i]=select[i] - set(["&"])



# getSelect(GStr,terminal,noterminal,null,unNull,first,follow,select)
# print(select)
