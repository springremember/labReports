#导入的模块
#判断是否能推出空模块
from null import *

#求first集合模块
from first import *

#求follow集合模块
from follow import *

#求select集合模块
from SELECT import *

#分析是否为LL文法
from LL import *

#求出预测分析表
from forM import *

#分析过程
from work import *

#从txt文件读入信息到一个列表，并排除换行符
def readFromTxt():
	with open("G.txt",'r') as f:
		lines=f.readlines()
	#排除空换行符
	for i in range(0,len(lines)):
		if lines[len(lines)-1]=='\n':
			del lines[len(lines)-1]
	return lines

#从信息中得到开始符号，对于类似G[E]格式进行切割
def getStart(list):
	return list[0][2:-3]

#对于类似E->TE',先分成[E,TE'],然后获取非终结符,并赋值
def getNoTerminal(list):
	temp={}
	#采用i来赋值
	for i in range(1,len(list)):
		xyz=list[i].split('->')
		temp[xyz[0]]=i-1
	return temp

def getNoTerminalList(list):
	temp=[]
	#采用i来赋值
	for i in range(1,len(list)):
		xyz=list[i].split('->')
		temp.append(xyz[0])
	return temp


#对于类似E'->+TE'，循环读取，遇到不是非终结符、&、|、’以外都为终结符。利用counter来赋值。
def getTerminal(list,noterminal):
	temp={}
	counter=0
	for i in range(1,len(list)):
		xyz=list[i].split('->')
		xyz[1]=xyz[1].rstrip('\n')
		for j in xyz[1]:
			if j in noterminal.keys() or j=='&' or j=='|' or j=="'":
				pass
			else:
				temp[j]=counter
				counter=counter+1
	temp['#']=counter
	return temp

#去除语法后面可能的换行符
def lines2G(list):
	temp=[]
	for i in range(1,len(list)):
		temp.append(list[i].rstrip('\n'))
	return temp

#将原本语法中F->i|(E)分开为F->i和F->(E)
def getGStr(G,Gtr):
	for i in G:
		tempList=i.split("->")
		tempList[1]=tempList[1].split("|")
		for j in tempList[1]:
			tempStr=tempList[0]+"->"+j
			GStr.append(tempStr)

#给select设置初值为空集合
def setSelect(GStr,select):
	for i in GStr:
		select[i]=set([])




#读取语法信息
#Glines是原始版本的TXT信息，G去除了可能的换行符
Glines=readFromTxt()
G=lines2G(Glines)

#start为开始符号，noterminal为非终结符的字典，terminal为终结符字典
start=getStart(Glines)
noterminal=getNoTerminal(Glines)
noterminalList=getNoTerminalList(Glines)
terminal=getTerminal(Glines,noterminal)

#为判断是否能推出空模块服务，分别保存未判断，已判空，非空几个集合
inDoubt=set(list(noterminal.keys()))
null=set([])
unNull=set([])

#first集合
first=[set([]) for i in range(0,len(noterminal))]

#follow集合
follow=[set([]) for i in range(0,len(noterminal))]
#select集合
select={}

#原本语法中F->i|(E)分开为F->i和F->(E)
GStr=[]

getGStr(G,GStr)
setSelect(GStr,select)

#M集合，用于存放分析预测表
M=[(["0"]*len(terminal)) for i in range(len(noterminal))]

#调用模块函数
getNull(G,noterminal,terminal,inDoubt,null,unNull)
getFirst(noterminal,terminal,G,null,unNull,first)
getFollow(start,noterminal,terminal,G,null,unNull,first,follow)
getSelect(GStr,terminal,noterminal,null,unNull,first,follow,select)
getM(terminal,noterminal,select,M)

#表格显示first、follow集合
def showNullFirstFollow(noterminalList,noterminal,null,first,follow):
	print("非终结符名"+'\t'+"是否推出空"+'\t'+"first集"+'\t\t\t\t'+"follow集")
	for i in noterminalList:
		print(i,end='\t\t')
		if i in null:
			print("是",end='\t\t')
		else:
			print("否",end='\t\t')
		print("%- 24s"%(first[noterminal[i]]),end='\t')
		print(follow[noterminal[i]],end='\n')

showNullFirstFollow(noterminalList,noterminal,null,first,follow)

#显示select集合
def showSelect(GStr,select):
	print('\n')
	print("select集合：")
	for i in GStr:
		print("SELECT("+i+")="+str(select[i]))
	print('\n')

showSelect(GStr,select)

#先判断是否是LL文法，如果是就进行预测判断。
if judgeLL(G,select,GStr):
	print("是LL文法")
	print('\n')
	analysis(noterminal,terminal,M,start)
else:
	print("不是LL文法")


