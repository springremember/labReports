

# start="E"

# noterminal={'E':0,"E'":1,'T':2,"T'":3,'F':4}
# terminal={'i':0,'(':1,')':2,'#':3,'+':4,'*':5}

# G=["E->TE'", "E'->+TE'|&", "T->FT'", "T'->*FT'|&", 'F->i|(E)']

# null=set(["E'","T'"])
# unNull=set(['E','T','F'])

# first=[{'i', '('}, {'&', '+'}, {'i', '('}, {'&', '*'}, {'i', '('}]

# follow=[{'#', ')'}, {'#', ')'}, {'+', '#', ')'}, {'+', '#', ')'}, {'+', '*', '#', ')'}]

# select={"T'->*FT'": {'*'}, 'F->i': {'i'}, "E->TE'": {'(', 'i'}, "E'->+TE'": {'+'}, 'F->(E)': {'('}, "E'->&": set(), "T->FT'": {'(', 'i'}, "T'->&": set()}

# GStr=["E->TE'", "E'->+TE'", "E'->&", "T->FT'", "T'->*FT'", "T'->&", 'F->i', 'F->(E)']

#判断是否是LL文法
#对于E->TE'|(A) 先用列表将select(E->TE')和select(E->(A))合并，然后集合去除重复元素。看是否个数变化。
def judgeLL(G,select,GStr):
	#一条语法一条语法分析
	for i in G:
		judegList=[]
		tempList=i.split('->')
		tempList[1]=tempList[1].split('|')
		#对于E->TB,只有一个分支的不需要再判断
		if len(tempList[1])==1:
			continue
		else:
			for j in tempList[1]:
				tempStr=tempList[0]+"->"+j
				#特殊的空串情况
				if j=="&":
					continue
				else:
					#合并列表
					ll=list(select[tempStr])
					judegList.extend(ll)
			#转化成集合判断
			judegSet=set(judegList)
			if len(judegSet)<len(judegList):
				return False
	return True


# if judgeLL(G,select,GStr):
# 	print("true")
# else:
# 	print("False")

