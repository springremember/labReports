#用于判断非终结符能否推出空

# noterminal={'E':0,'A':1,'T':2,'B':3,'F':4}
# terminal={'i':0,'(':1,')':2,'#':3,'+':4,'*':5}

# G=["E->TA","A->+TA|&","T->FB","B->*FB|&","F->i|(E)"]

# inDoubt=set(list(noterminal.keys()))
# null=set([])
# unNull=set([])

#判断是否存在非识别的非终结符
#inDoubt:未判别的非终结符
def juggle(unNull,tempList,inDoubt):
	flag=0
	for i in tempList[1]:
		for j in range(0,len(i)):
			if i[j]=="'":
				pass
			elif j==len(i)-1:
				if i[j] in inDoubt:
					return True
			elif i[j+1]=="'":
				tempStr=i[j]+i[j+1]
				if tempStr in inDoubt:
					return True
			else:
				if i[j] in inDoubt:
					return True
	return False

#判断是否推导式中全为空
def juggleNull(null,tempList):
	for i in tempList[1]:
		counter=0
		for j in range(0,len(i)):
			if i[j]=="'":
				pass
			elif j==len(i)-1:
				if i[j] in null:
					counter=counter+1
			elif i[j+1]=="'":
				tempStr=i[j]+i[j+1]
				if tempStr in null:
					counter=counter+1
			else:
				if i[j] in null:
					counter=counter+1
		if counter==len(i):
			return True
	return False

#判断函数
def getNull(G,noterminal,terminal,inDoubt,null,unNull):
	#第一步，找出可推出空的非终结符
	for GStr in G:
		tempList=GStr.split("->")
		tempList[1]=tempList[1].split("|")
		for i in tempList[1]:
			if i=='&':
				inDoubt.remove(tempList[0])
				null.add(tempList[0])

	#第二步，找出必然为非空的非终结符
	for GStr in G:
		print(GStr)
		counter=0
		tempList=GStr.split("->")
		tempList[1]=tempList[1].split("|")
		for i in tempList[1]:
			if i[0] in terminal.keys():
				counter=counter+1
		if counter==len(tempList[1]):
			inDoubt.remove(tempList[0])
			unNull.add(tempList[0])

	#第三步，循环判断
	while 1:
		if len(inDoubt)==0:
			break;
		#寻找一个未判断的非终结符
		inDoubtList=list(inDoubt)
		for sym in inDoubtList:
			tempList=G[noterminal[sym]].split("->")
			tempList[1]=tempList[1].split("|")
			#判断其中是否有未判断非终结符，如果有就跳过
			if juggle(unNull,tempList,inDoubt):
				continue
			else:
				#判断是否推导式全为空，否则不能推出空
				if juggleNull(null,tempList):
					inDoubt.remove(sym)
					Null.add(sym)
				else:
					inDoubt.remove(sym)
					unNull.add(sym)


# getNull(G,noterminal,terminal,inDoubt,null,unNull)
# print("可以推出空的：",end="")
# print(null)
# print("无法推出空的：",end="")
# print(unNull)



